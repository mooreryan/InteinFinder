# Basic Usage

This directory contains data for a tutorial on the basic usage of InteinFinder, including

- Making a simple config file
- Running the software
- Checking the output
- Generating intein free extein sequences

The full write-up can be found on the InteinFinder [docs](https://mooreryan.github.io/InteinFinder/basic-usage) website.
